# RentEase – AI-Powered Property & Rental Management

An all-in-one property and rental management platform designed specifically for small-scale property owners managing multiple houses or portions within a compound. RentEase simplifies monthly rent collection, tenant history, camera-based electricity (EB) meter reading extraction with verification, evidence preservation, and monthly income analytics.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed:
> 1. **Dual-Mode Connectivity**: Starts with instant browser persistence (zero configuration needed to begin using immediately) alongside a live Supabase connector that provides complete copy-paste PostgreSQL schema migrations, RLS policies, and storage setup.
> 2. **Hybrid AI Vision**: Client-side HTML5 Canvas calculates image sharpness and blur scores in real-time, while server-side Gemini 3.8 Flash analyzes 7-segment digital meters, dial digits, and meter serial verification, with client-side Tesseract.js as a local offline fallback.
> 3. **Clean Blank State**: Starts fresh with an empty compound, featuring an intuitive guided setup wizard for the owner to register their property, first house, tenant, and EB meter.
> 4. **No External Information Needed Upfront**: No GitHub access or upfront database credentials are required to start building. The application will be fully operational immediately, and live Supabase credentials can be added anytime in the Database Settings tab.

---

## 1. Overview & Core Concept

- **What It Does**: Enables small-scale landlords to track houses/portions in a compound, assign tenants, collect and record monthly rent (with UPI/bank/cash screenshots), photograph electricity meters with automatic digit extraction and serial number validation, track electricity consumption, and view pure rental income analytics.
- **Target Audience**: Compound owners and small-scale landlords who need an easy-to-use, professional tool tailored to Indian rental conventions (INR ₹ currency, Asia/Kolkata timezone, EB meter tracking, UPI payment proofs).
- **Core Value**: Eliminates manual diary errors, prevents meter mix-ups through serial verification, ensures tamper-free evidence preservation for payments and electricity readings, and separates pure rental income from utility bills.

---

## 2. User Experience & Visual Design

### Design Language & Color Palette
Tailored to the user's specified warm, premium, and professional color palette:
- **Canvas / Background**: Warm Cream `#F2EBDC`
- **Surface / Card Background**: Light Cream `#F7F3E8`
- **Secondary Neutral**: Sandy Beige `#DDD2B4`
- **Primary Action Green**: Deep Forest Green `#2E6B4A`
- **Interactive Button Green**: `#3F7F5C` (Hover: `#6FAF87`)
- **Accent & Light Surfaces**: Mint Sage `#A9D3B7`
- **Typography & Ink**: Primary Charcoal `#2C2C2C`, Secondary Slate `#6B6B6B`, Muted `#9A9A9A`
- **Fonts**: `Plus Jakarta Sans` for clean, professional headings and navigation; `Manrope` for dense body content; `JetBrains Mono` / `tabular-nums` for currency figures, readings, and dates.

### Navigation Architecture
- **Sidebar**:
  1. **Dashboard**: High-level rent collection pulse, pending rent, quick actions, active tenants count.
  2. **Houses & Portions**: Compound card grid, portion occupancy, assigned meters, EB responsibility tags.
  3. **Rent Management**: Monthly payment records, status toggles (Paid, Unpaid, Partially Paid), evidence upload, audit logs.
  4. **EB Meter Readings**: Camera capture screen, OCR extractor, blur detector, serial mismatch guard, confirmation modal.
  5. **EB Consumption History**: Month-over-month consumption tables, tenant-wise usage, rollover/negative-consumption alerts, CSV export.
  6. **Income Analytics**: Pure rental income charts (excluding EB), monthly and yearly comparison, tenant-wise income breakdowns.
  7. **Settings & Database**: Owner profile, Supabase sync status, SQL migration generator, EB unit rate settings, and data backup/export.

---

## 3. Key Product Decisions & Architectural Strategy

### Decision 1: Dual-Mode Persistence (IndexedDB + Live Supabase PostgreSQL)
- **Chosen Approach**: Built-in repository pattern. `StorageService` operates against an indexed local database by default, maintaining the complete 11-table relational schema. When the owner enters their `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`, it seamlessly switches to the remote Supabase client.
- **Why**: Allows instant testing in the sandbox without blocking on manual external project creation, while providing full production-ready PostgreSQL schemas and RLS policies.

### Decision 2: Hybrid AI Meter Extraction & Multi-Layer Verification
- **Layer 1 (Canvas Preprocessing)**: Real-time image sharpness calculation using the Laplacian variance algorithm on HTML5 canvas. Low scores immediately trigger a "Blurry Image – Please Retake" notification.
- **Layer 2 (Gemini 3.8 Flash Vision)**: Server proxy route `/api/meter/read` inspects the meter display (7-segment LCD or dial), extracts numeric kWh, and identifies the printed meter serial number.
- **Layer 3 (Serial Verification)**: Compares extracted serial against the registered meter's `serial_number`. If a mismatch is detected, shows a prominent warning: *"Potential meter mismatch detected. Registered: ABC123 vs Detected: XYZ789"*.
- **Layer 4 (Human Confirmation)**: Owner inspects the detected value side-by-side with the image and confirms or corrects before saving.

### Decision 3: Strict Isolation Between Rent and EB Utility Charges
- In accordance with prompt requirements, rental income analytics will strictly track **rent collected**. Electricity bills paid by tenants directly or reimbursed to the owner are accounted for in the EB module and will not be conflated with rental income.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        RentEase Web Application                        │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
           ┌────────────────────────┴────────────────────────┐
           ▼                                                 ▼
┌─────────────────────────────┐                  ┌───────────────────────┐
│     Client UI (React 19)    │                  │  Express API Server   │
│ ─────────────────────────── │                  │ ───────────────────── │
│ - Plus Jakarta Sans & Icons │                  │ - /api/meter/read     │
│ - HTML5 Camera / Upload     │                  │   (Gemini 3.8 Flash)  │
│ - Recharts Analytics        │                  │ - Health check        │
│ - Storage & Auth Facade     │                  └───────────────────────┘
└──────────┬──────────────────┘
           │
           ├──────────────────────────────┐
           ▼                              ▼
┌─────────────────────────────┐ ┌────────────────────────────────────────┐
│   Local Persistence Store   │ │        Supabase Cloud (Optional)       │
│  (IndexedDB / LocalStorage) │ │  - PostgreSQL with RLS                 │
│  - 11 relational tables     │ │  - Supabase Storage buckets            │
│  - Full audit logging       │ │  - Direct 1-click sync & SQL script    │
└─────────────────────────────┘ └────────────────────────────────────────┘
```

### Database Entities & Relations
1. **owners**: `id`, `email`, `name`, `phone`, `compound_name`, `created_at`
2. **houses**: `id`, `owner_id`, `name`, `house_number`, `monthly_rent`, `eb_responsibility` ('owner' | 'tenant_direct'), `description`, `is_active`
3. **tenants**: `id`, `owner_id`, `name`, `phone`, `email`, `id_proof_number`, `status`
4. **tenancy_history**: `id`, `house_id`, `tenant_id`, `start_date`, `end_date`, `monthly_rent_agreed`, `deposit_amount`, `is_current`
5. **meters**: `id`, `house_id`, `meter_number`, `serial_number`, `reference_photo_url`, `created_at`
6. **meter_readings**: `id`, `house_id`, `meter_id`, `tenant_id`, `month`, `year`, `previous_reading`, `current_reading`, `units_consumed`, `is_corrected`, `correction_reason`
7. **meter_evidence**: `id`, `reading_id`, `image_url`, `extracted_reading`, `confirmed_reading`, `detected_serial`, `blur_score`, `verification_status`, `captured_at`
8. **rent_payments**: `id`, `house_id`, `tenant_id`, `month`, `year`, `rent_due`, `amount_paid`, `balance_due`, `payment_status` ('paid' | 'unpaid' | 'partial'), `payment_method`, `payment_date`
9. **rent_evidence**: `id`, `payment_id`, `image_url`, `file_name`, `uploaded_at`
10. **eb_payments**: `id`, `house_id`, `month`, `year`, `bill_amount`, `paid_status`, `payment_date`, `receipt_url`
11. **audit_logs**: `id`, `entity_type`, `entity_id`, `action`, `old_value`, `new_value`, `reason`, `timestamp`

---

## 5. Step-by-Step Execution Plan

1. **Backend Server Setup**:
   - Create Express server (`server.ts`) listening on port 3000.
   - Implement `/api/meter/read` endpoint using `@google/genai` (with `gemini-3.8-flash`) to parse meter displays, detect glare/reflection, and read serial numbers.
2. **Database Engine & Supabase Integration**:
   - Build `src/services/db.ts` implementing the full 11-table schema in IndexedDB with relational integrity.
   - Provide complete SQL export (`supabase_schema.sql`) for one-click setup in Supabase SQL editor.
   - Implement Supabase client wrapper with live connection toggle.
3. **UI Theme & Core Navigation**:
   - Configure Tailwind with the warm cream and deep forest green palette (`#F2EBDC`, `#F7F3E8`, `#2E6B4A`).
   - Create TopBar and Responsive Sidebar navigation with mobile support.
4. **Clean Slate & Guided Onboarding**:
   - Provide an empty state wizard allowing the owner to configure their compound, first house/portion, tenant, and meter details.
5. **House & Tenant Management (Module 1)**:
   - Add/Edit House modal with EB responsibility toggle (`Owner pays` vs `Tenant pays directly`).
   - Tenant profile view with complete historical tenancy association.
6. **AI EB Meter Reading & Evidence (Module 2 & 3)**:
   - Camera interface with file upload fallback.
   - Real-time HTML5 Canvas blur and glare detection.
   - Gemini multimodal extraction + serial verification against registered meter.
   - Side-by-side verification and manual override confirmation modal.
   - Automatic consumption calculation: `Units = Current - Previous`. Flag rollover or negative readings.
   - Evidence gallery to view full photo records month-by-month.
7. **Rent Payment Management & Proofs (Module 4)**:
   - Monthly payment table for all houses.
   - Status updates: Paid, Unpaid, Partially Paid (with balance calculation).
   - UPI/Bank screenshot upload with preview modal.
   - Audit trail for payment status changes.
8. **Monthly Income Analytics (Module 5)**:
   - Dashboard KPI metric cards (Rent Collected, Rent Pending, Annual Total, Paid vs Unpaid).
   - Monthly income bar chart using Recharts (pure rental income only).
   - Export reports as CSV.
9. **Settings & Data Export**:
   - Owner profile, EB unit rate configuration, Supabase connection manager, and complete data backup export/import.
10. **Verification & Testing**:
    - End-to-end verification of camera capture, rent calculations, tenant transitions, and data integrity.
